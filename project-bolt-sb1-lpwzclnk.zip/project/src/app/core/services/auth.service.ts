import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: 'USER' | 'ADMIN';
}

export interface UserCredentials {
  email: string;
  password: string;
  fullName?: string;
  phone?: string;
  address?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  
  // Mock admin user
  private mockUsers: User[] = [
    {
      id: '1',
      email: 'admin@example.com',
      fullName: 'Admin User',
      role: 'ADMIN'
    },
    {
      id: '2',
      email: 'user@example.com',
      fullName: 'Regular User',
      role: 'USER'
    }
  ];
  
  constructor(private router: Router) {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
  }
  
  login(credentials: {email: string, password: string}) {
    // For demo purposes, we'll just check if the email matches one of our mock users
    const user = this.mockUsers.find(u => u.email === credentials.email);
    
    if (user) {
      // Store the user in localStorage
      localStorage.setItem('currentUser', JSON.stringify(user));
      this.currentUserSubject.next(user);
      return true;
    }
    
    return false;
  }
  
  register(credentials: UserCredentials) {
    // In a real app, you would make an API call to register the user
    const newUser: User = {
      id: (this.mockUsers.length + 1).toString(),
      email: credentials.email,
      fullName: credentials.fullName || 'New User',
      role: 'USER'
    };
    
    this.mockUsers.push(newUser);
    
    // Auto-login after registration
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    this.currentUserSubject.next(newUser);
    
    return true;
  }
  
  logout() {
    // Remove user from localStorage
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    this.router.navigate(['/']);
  }
  
  isAuthenticated(): boolean {
    return !!this.currentUserSubject.value;
  }
  
  isAdmin(): boolean {
    const user = this.currentUserSubject.value;
    return !!user && user.role === 'ADMIN';
  }
  
  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }
}