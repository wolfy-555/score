import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <header class="header">
      <div class="container">
        <div class="header-content">
          <div class="logo">
            <a routerLink="/">
              <h1>WatchLuxe</h1>
            </a>
          </div>
          
          <nav class="main-nav">
            <ul class="nav-list">
              <li><a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Home</a></li>
              <li class="dropdown">
                <a>Categories</a>
                <div class="dropdown-content">
                  <a routerLink="/products/ANALOGUE">Analogue</a>
                  <a routerLink="/products/DIGITAL">Digital</a>
                  <a routerLink="/products/LUXURY">Luxury</a>
                </div>
              </li>
              <li><a routerLink="/products" routerLinkActive="active">All Watches</a></li>
            </ul>
          </nav>
          
          <div class="user-actions">
            <a routerLink="/cart" class="cart-icon" routerLinkActive="active">
              Cart
              <span class="cart-count" *ngIf="cartItemCount > 0">{{ cartItemCount }}</span>
            </a>
            
            <ng-container *ngIf="isLoggedIn; else loginButton">
              <div class="dropdown">
                <button class="dropdown-btn">My Account</button>
                <div class="dropdown-content">
                  <a routerLink="/profile">Profile</a>
                  <a *ngIf="isAdmin" routerLink="/admin">Admin</a>
                  <a (click)="logout()">Logout</a>
                </div>
              </div>
            </ng-container>
            
            <ng-template #loginButton>
              <a routerLink="/auth/login" class="btn btn-primary">Login</a>
            </ng-template>
          </div>
          
          <button class="mobile-menu-toggle" (click)="toggleMobileMenu()">
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .header {
      background-color: var(--background-white);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1000;
    }
    
    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: var(--spacing-unit) 0;
    }
    
    .logo h1 {
      margin: 0;
      font-size: 1.75rem;
      color: var(--primary-color);
    }
    
    .main-nav {
      display: flex;
    }
    
    .nav-list {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }
    
    .nav-list li {
      margin: 0 calc(var(--spacing-unit) * 2);
    }
    
    .nav-list a {
      color: var(--text-primary);
      font-weight: 500;
      position: relative;
      cursor: pointer;
    }
    
    .nav-list a.active::after,
    .nav-list a:hover::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 2px;
      background-color: var(--secondary-color);
    }
    
    .dropdown {
      position: relative;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: var(--background-white);
      min-width: 160px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
      z-index: 1;
      border-radius: var(--border-radius);
      padding: var(--spacing-unit) 0;
    }
    
    .dropdown-content a {
      display: block;
      padding: calc(var(--spacing-unit) * 1.5);
      color: var(--text-primary);
    }
    
    .dropdown-content a:hover {
      background-color: var(--background-light);
    }
    
    .dropdown:hover .dropdown-content {
      display: block;
    }
    
    .user-actions {
      display: flex;
      align-items: center;
    }
    
    .cart-icon {
      margin-right: calc(var(--spacing-unit) * 3);
      position: relative;
    }
    
    .cart-count {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: var(--secondary-color);
      color: white;
      border-radius: 50%;
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
    }
    
    .dropdown-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-family: 'Poppins', sans-serif;
      font-weight: 500;
      color: var(--primary-color);
    }
    
    .mobile-menu-toggle {
      display: none;
      background: none;
      border: none;
      cursor: pointer;
    }
    
    .mobile-menu-toggle span {
      display: block;
      width: 25px;
      height: 3px;
      background-color: var(--primary-color);
      margin: 5px 0;
      transition: all 0.3s ease;
    }
    
    @media (max-width: 768px) {
      .main-nav {
        display: none;
      }
      
      .mobile-menu-toggle {
        display: block;
      }
      
      .main-nav.active {
        display: block;
        position: absolute;
        top: 70px;
        left: 0;
        width: 100%;
        background-color: var(--background-white);
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
      }
      
      .nav-list {
        flex-direction: column;
        padding: var(--spacing-unit) 0;
      }
      
      .nav-list li {
        margin: 0;
        padding: calc(var(--spacing-unit) * 1.5) calc(var(--spacing-unit) * 2);
      }
      
      .dropdown-content {
        position: static;
        box-shadow: none;
        padding-left: calc(var(--spacing-unit) * 2);
      }
      
      .user-actions {
        flex-direction: column;
      }
    }
  `]
})
export class HeaderComponent {
  isLoggedIn = false;
  isAdmin = false;
  cartItemCount = 0;
  mobileMenuOpen = false;
  
  constructor(
    private authService: AuthService,
    private cartService: CartService
  ) {}
  
  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = !!user;
      this.isAdmin = user?.role === 'ADMIN';
    });
    
    this.cartService.cart$.subscribe(cart => {
      this.cartItemCount = cart.reduce((count, item) => count + item.quantity, 0);
    });
  }
  
  logout() {
    this.authService.logout();
  }
  
  toggleMobileMenu() {
    this.mobileMenuOpen = !this.mobileMenuOpen;
  }
}