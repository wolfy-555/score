import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="not-found-container">
      <div class="container text-center">
        <h1>404</h1>
        <h2>Page Not Found</h2>
        <p>The page you are looking for doesn't exist or has been moved.</p>
        <a routerLink="/" class="btn btn-primary">Return to Home</a>
      </div>
    </div>
  `,
  styles: [`
    .not-found-container {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 60vh;
      text-align: center;
    }
    
    h1 {
      font-size: 6rem;
      color: var(--secondary-color);
      margin-bottom: var(--spacing-unit);
    }
    
    h2 {
      font-size: 2.5rem;
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    p {
      font-size: 1.2rem;
      margin-bottom: calc(var(--spacing-unit) * 4);
      color: var(--text-secondary);
    }
  `]
})
export class NotFoundComponent {}