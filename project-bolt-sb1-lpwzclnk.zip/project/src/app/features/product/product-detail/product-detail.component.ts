import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { ProductService, Product } from '../../../core/services/product.service';
import { CartService } from '../../../core/services/cart.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="product-detail-container">
      <div class="container">
        <div *ngIf="loading" class="loading">
          <p>Loading product details...</p>
        </div>
        
        <div *ngIf="!loading && !product" class="product-not-found">
          <h2>Product Not Found</h2>
          <p>Sorry, the product you're looking for doesn't exist.</p>
          <a routerLink="/products" class="btn btn-primary">Browse All Watches</a>
        </div>
        
        <div *ngIf="!loading && product" class="product-details">
          <div class="product-gallery">
            <div class="main-image">
              <img [src]="selectedImage" [alt]="product.name">
            </div>
            
            <div class="thumbnail-images">
              <div 
                *ngFor="let image of product.images" 
                class="thumbnail" 
                [class.active]="image === selectedImage"
                (click)="selectImage(image)"
              >
                <img [src]="image" [alt]="product.name">
              </div>
            </div>
          </div>
          
          <div class="product-info">
            <h1>{{ product.name }}</h1>
            <div class="product-category">{{ product.category }}</div>
            <div class="product-price">${{ product.price.toFixed(2) }}</div>
            
            <div class="product-description">
              <p>{{ product.description }}</p>
            </div>
            
            <div class="product-stock" [class.in-stock]="product.stock > 0" [class.out-of-stock]="product.stock === 0">
              {{ product.stock > 0 ? 'In Stock' : 'Out of Stock' }}
              <span *ngIf="product.stock > 0 && product.stock < 10" class="low-stock">
                (Only {{ product.stock }} left)
              </span>
            </div>
            
            <div class="quantity-selector">
              <label for="quantity">Quantity:</label>
              <div class="quantity-controls">
                <button (click)="decreaseQuantity()" [disabled]="quantity <= 1">-</button>
                <input type="number" id="quantity" [(ngModel)]="quantity" min="1" [max]="product.stock">
                <button (click)="increaseQuantity()" [disabled]="quantity >= product.stock">+</button>
              </div>
            </div>
            
            <div class="product-actions">
              <button 
                class="btn btn-primary" 
                (click)="addToCart()" 
                [disabled]="product.stock === 0"
              >
                Add to Cart
              </button>
              <a routerLink="/products" class="btn btn-outline">Continue Shopping</a>
            </div>
            
            <div class="product-specifications">
              <h3>Specifications</h3>
              <div class="specifications-list">
                <div class="spec-item" *ngFor="let spec of specifications">
                  <div class="spec-name">{{ spec.name }}</div>
                  <div class="spec-value">{{ spec.value }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .product-detail-container {
      padding: calc(var(--spacing-unit) * 4) 0;
    }
    
    .loading, .product-not-found {
      text-align: center;
      padding: calc(var(--spacing-unit) * 8) 0;
    }
    
    .product-not-found p {
      margin-bottom: calc(var(--spacing-unit) * 3);
      color: var(--text-secondary);
    }
    
    .product-details {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: calc(var(--spacing-unit) * 6);
    }
    
    .product-gallery {
      position: sticky;
      top: calc(var(--spacing-unit) * 10);
    }
    
    .main-image {
      border-radius: var(--border-radius);
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .main-image img {
      width: 100%;
      height: auto;
      display: block;
    }
    
    .thumbnail-images {
      display: flex;
      gap: var(--spacing-unit);
    }
    
    .thumbnail {
      width: 80px;
      height: 80px;
      border-radius: var(--border-radius);
      overflow: hidden;
      border: 2px solid transparent;
      cursor: pointer;
      opacity: 0.7;
      transition: all 0.3s ease;
    }
    
    .thumbnail.active {
      border-color: var(--secondary-color);
      opacity: 1;
    }
    
    .thumbnail:hover {
      opacity: 1;
    }
    
    .thumbnail img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .product-info h1 {
      margin-bottom: var(--spacing-unit);
    }
    
    .product-category {
      display: inline-block;
      background-color: var(--background-light);
      padding: calc(var(--spacing-unit) * 0.5) var(--spacing-unit);
      border-radius: var(--border-radius);
      font-size: 0.875rem;
      color: var(--text-secondary);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .product-price {
      font-size: 2rem;
      font-weight: 600;
      color: var(--primary-color);
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .product-description {
      margin-bottom: calc(var(--spacing-unit) * 3);
      color: var(--text-secondary);
      line-height: 1.6;
    }
    
    .product-stock {
      margin-bottom: calc(var(--spacing-unit) * 3);
      font-weight: 500;
    }
    
    .in-stock {
      color: var(--success-color);
    }
    
    .out-of-stock {
      color: var(--error-color);
    }
    
    .low-stock {
      color: var(--warning-color);
      font-size: 0.875rem;
      margin-left: var(--spacing-unit);
    }
    
    .quantity-selector {
      display: flex;
      align-items: center;
      gap: var(--spacing-unit);
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .quantity-controls {
      display: flex;
      align-items: center;
    }
    
    .quantity-controls button {
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: var(--background-light);
      border: none;
      cursor: pointer;
      font-size: 1.2rem;
      border-radius: var(--border-radius);
    }
    
    .quantity-controls input {
      width: 50px;
      height: 30px;
      text-align: center;
      border: 1px solid #ccc;
      margin: 0 var(--spacing-unit);
    }
    
    .product-actions {
      display: flex;
      gap: var(--spacing-unit);
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .btn-outline {
      border: 1px solid var(--primary-color);
      color: var(--primary-color);
      background-color: transparent;
      padding: calc(var(--spacing-unit) * 1.5) calc(var(--spacing-unit) * 3);
      border-radius: var(--border-radius);
      font-family: 'Poppins', sans-serif;
      font-weight: 500;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .btn-outline:hover {
      background-color: var(--primary-color);
      color: white;
    }
    
    .product-specifications {
      background-color: var(--background-light);
      border-radius: var(--border-radius);
      padding: calc(var(--spacing-unit) * 3);
    }
    
    .product-specifications h3 {
      margin-bottom: calc(var(--spacing-unit) * 2);
      font-size: 1.2rem;
    }
    
    .specifications-list {
      display: grid;
      gap: var(--spacing-unit);
    }
    
    .spec-item {
      display: flex;
      border-bottom: 1px solid rgba(0, 0, 0, 0.1);
      padding-bottom: var(--spacing-unit);
    }
    
    .spec-name {
      flex: 1;
      font-weight:  500;
      color: var(--text-secondary);
    }
    
    .spec-value {
      flex: 2;
    }
    
    @media (max-width: 992px) {
      .product-details {
        grid-template-columns: 1fr;
      }
      
      .product-gallery {
        position: static;
      }
    }
    
    @media (max-width: 576px) {
      .product-actions {
        flex-direction: column;
      }
    }
  `]
})
export class ProductDetailComponent implements OnInit {
  product: Product | undefined;
  loading = true;
  selectedImage = '';
  quantity = 1;
  specifications: {name: string, value: string}[] = [];
  
  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  
  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const productId = params.get('id');
      
      if (productId) {
        this.loadProduct(productId);
      } else {
        this.router.navigate(['/products']);
      }
    });
  }
  
  loadProduct(id: string): void {
    this.loading = true;
    
    this.productService.getProductById(id).subscribe(product => {
      this.product = product;
      this.loading = false;
      
      if (product) {
        this.selectedImage = product.images[0];
        this.specifications = Object.entries(product.specifications).map(([name, value]) => ({
          name,
          value
        }));
      }
    });
  }
  
  selectImage(image: string): void {
    this.selectedImage = image;
  }
  
  increaseQuantity(): void {
    if (this.product && this.quantity < this.product.stock) {
      this.quantity++;
    }
  }
  
  decreaseQuantity(): void {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }
  
  addToCart(): void {
    if (this.product) {
      this.cartService.addToCart(this.product, this.quantity);
      alert(`${this.quantity} ${this.product.name} added to cart!`);
    }
  }
}