import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService, CartItem } from '../../core/services/cart.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="cart-container">
      <div class="container">
        <header class="page-header">
          <h1>Your Shopping Cart</h1>
          <p *ngIf="cartItems.length">You have {{ cartItems.length }} item(s) in your cart</p>
        </header>
        
        <div *ngIf="cartItems.length === 0" class="empty-cart">
          <div class="empty-cart-message">
            <h2>Your cart is empty</h2>
            <p>Looks like you haven't added any watches to your cart yet.</p>
            <a routerLink="/products" class="btn btn-primary">Start Shopping</a>
          </div>
        </div>
        
        <div *ngIf="cartItems.length > 0" class="cart-content">
          <div class="cart-items">
            <div class="cart-item" *ngFor="let item of cartItems">
              <div class="item-image">
                <img [src]="item.images[0]" [alt]="item.name">
              </div>
              
              <div class="item-details">
                <h3>{{ item.name }}</h3>
                <span class="item-category">{{ item.category }}</span>
                <div class="item-price">${{ item.price.toFixed(2) }}</div>
              </div>
              
              <div class="item-quantity">
                <div class="quantity-controls">
                  <button (click)="decreaseQuantity(item)" [disabled]="item.quantity <= 1">-</button>
                  <input type="number" [(ngModel)]="item.quantity" (change)="updateQuantity(item)" min="1" [max]="item.stock">
                  <button (click)="increaseQuantity(item)" [disabled]="item.quantity >= item.stock">+</button>
                </div>
              </div>
              
              <div class="item-subtotal">
                ${{ item.subtotal.toFixed(2) }}
              </div>
              
              <button class="remove-item" (click)="removeItem(item)">
                &times;
              </button>
            </div>
          </div>
          
          <div class="cart-summary">
            <h3>Order Summary</h3>
            
            <div class="summary-row">
              <span>Subtotal:</span>
              <span>${{ cartTotal.toFixed(2) }}</span>
            </div>
            
            <div class="summary-row">
              <span>Shipping:</span>
              <span>${{ shipping.toFixed(2) }}</span>
            </div>
            
            <div class="summary-row">
              <span>Tax:</span>
              <span>${{ tax.toFixed(2) }}</span>
            </div>
            
            <div class="summary-total">
              <span>Total:</span>
              <span>${{ orderTotal.toFixed(2) }}</span>
            </div>
            
            <button class="btn btn-primary checkout-btn">Proceed to Checkout</button>
            
            <div class="cart-actions">
              <a routerLink="/products" class="continue-shopping">Continue Shopping</a>
              <button class="clear-cart" (click)="clearCart()">Clear Cart</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .cart-container {
      padding: calc(var(--spacing-unit) * 4) 0;
    }
    
    .page-header {
      margin-bottom: calc(var(--spacing-unit) * 4);
      text-align: center;
    }
    
    .empty-cart {
      padding: calc(var(--spacing-unit) * 8) 0;
      text-align: center;
    }
    
    .empty-cart-message h2 {
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .empty-cart-message p {
      margin-bottom: calc(var(--spacing-unit) * 4);
      color: var(--text-secondary);
    }
    
    .cart-content {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: calc(var(--spacing-unit) * 4);
    }
    
    .cart-items {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: calc(var(--spacing-unit) * 3);
    }
    
    .cart-item {
      display: flex;
      align-items: center;
      padding: calc(var(--spacing-unit) * 2) 0;
      border-bottom: 1px solid var(--background-light);
      position: relative;
    }
    
    .cart-item:last-child {
      border-bottom: none;
    }
    
    .item-image {
      width: 80px;
      height: 80px;
      border-radius: var(--border-radius);
      overflow: hidden;
      margin-right: calc(var(--spacing-unit) * 2);
    }
    
    .item-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .item-details {
      flex: 1;
    }
    
    .item-details h3 {
      margin-bottom: calc(var(--spacing-unit) * 0.5);
      font-size: 1.1rem;
    }
    
    .item-category {
      display: inline-block;
      background-color: var(--background-light);
      padding: 2px var(--spacing-unit);
      border-radius: var(--border-radius);
      font-size: 0.75rem;
      color: var(--text-secondary);
      margin-bottom: calc(var(--spacing-unit) * 1);
    }
    
    .item-price {
      font-weight: 500;
      color: var(--text-secondary);
    }
    
    .item-quantity {
      margin: 0 calc(var(--spacing-unit) * 3);
    }
    
    .quantity-controls {
      display: flex;
      align-items: center;
    }
    
    .quantity-controls button {
      width: 25px;
      height: 25px;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: var(--background-light);
      border: none;
      cursor: pointer;
      font-size: 1rem;
      border-radius: var(--border-radius);
    }
    
    .quantity-controls input {
      width: 40px;
      height: 25px;
      text-align: center;
      border: 1px solid #ccc;
      margin: 0 var(--spacing-unit);
    }
    
    .item-subtotal {
      font-weight: 600;
      font-size: 1.1rem;
      color: var(--primary-color);
      width: 100px;
      text-align: right;
    }
    
    .remove-item {
      background: none;
      border: none;
      color: var(--text-secondary);
      font-size: 1.5rem;
      cursor: pointer;
      margin-left: var(--spacing-unit);
      transition: color 0.3s ease;
    }
    
    .remove-item:hover {
      color: var(--error-color);
    }
    
    .cart-summary {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: calc(var(--spacing-unit) * 3);
      align-self: flex-start;
      position: sticky;
      top: calc(var(--spacing-unit) * 10);
    }
    
    .cart-summary h3 {
      margin-bottom: calc(var(--spacing-unit) * 3);
      padding-bottom: var(--spacing-unit);
      border-bottom: 1px solid var(--background-light);
    }
    
    .summary-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: calc(var(--spacing-unit) * 2);
      color: var(--text-secondary);
    }
    
    .summary-total {
      display: flex;
      justify-content: space-between;
      margin: calc(var(--spacing-unit) * 3) 0;
      padding-top: calc(var(--spacing-unit) * 2);
      border-top: 1px solid var(--background-light);
      font-weight: 600;
      font-size: 1.2rem;
      color: var(--primary-color);
    }
    
    .checkout-btn {
      width: 100%;
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .cart-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .continue-shopping {
      color: var(--accent-color);
      text-decoration: underline;
      font-size: 0.9rem;
    }
    
    .clear-cart {
      background: none;
      border: none;
      color: var(--error-color);
      text-decoration: underline;
      font-size: 0.9rem;
      cursor: pointer;
    }
    
    @media (max-width: 992px) {
      .cart-content {
        grid-template-columns: 1fr;
      }
      
      .cart-summary {
        position: static;
      }
    }
    
    @media (max-width: 576px) {
      .cart-item {
        flex-wrap: wrap;
      }
      
      .item-details {
        width: calc(100% - 100px);
        margin-bottom: var(--spacing-unit);
      }
      
      .item-quantity {
        margin: 0;
        margin-right: auto;
      }
      
      .item-subtotal {
        text-align: left;
      }
    }
  `]
})
export class CartComponent implements OnInit {
  cartItems: CartItem[] = [];
  cartTotal = 0;
  shipping = 10.00;
  tax = 0;
  orderTotal = 0;
  
  constructor(private cartService: CartService) {}
  
  ngOnInit(): void {
    this.cartService.cart$.subscribe(cart => {
      this.cartItems = cart;
      this.calculateTotals();
    });
  }
  
  calculateTotals(): void {
    // Calculate subtotal
    this.cartTotal = this.cartItems.reduce((total, item) => total + item.subtotal, 0);
    
    // Calculate tax (e.g., 8%)
    this.tax = this.cartTotal * 0.08;
    
    // Calculate order total
    this.orderTotal = this.cartTotal + this.shipping + this.tax;
  }
  
  increaseQuantity(item: CartItem): void {
    if (item.quantity < item.stock) {
      this.cartService.updateQuantity(item.id, item.quantity + 1);
    }
  }
  
  decreaseQuantity(item: CartItem): void {
    if (item.quantity > 1) {
      this.cartService.updateQuantity(item.id, item.quantity - 1);
    }
  }
  
  updateQuantity(item: CartItem): void {
    // Ensure quantity is within bounds
    if (item.quantity < 1) {
      item.quantity = 1;
    } else if (item.quantity > item.stock) {
      item.quantity = item.stock;
    }
    
    this.cartService.updateQuantity(item.id, item.quantity);
  }
  
  removeItem(item: CartItem): void {
    if (confirm(`Remove ${item.name} from cart?`)) {
      this.cartService.removeFromCart(item.id);
    }
  }
  
  clearCart(): void {
    if (confirm('Are you sure you want to clear your cart?')) {
      this.cartService.clearCart();
    }
  }
}