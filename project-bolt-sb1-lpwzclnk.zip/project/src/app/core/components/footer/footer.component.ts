import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink],
  template: `
    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-section">
            <h3>WatchLuxe</h3>
            <p>Discover the finest selection of luxury timepieces from around the world.</p>
          </div>
          
          <div class="footer-section">
            <h4>Shop</h4>
            <ul>
              <li><a routerLink="/products/ANALOGUE">Analogue Watches</a></li>
              <li><a routerLink="/products/DIGITAL">Digital Watches</a></li>
              <li><a routerLink="/products/LUXURY">Luxury Collections</a></li>
              <li><a routerLink="/products">New Arrivals</a></li>
            </ul>
          </div>
          
          <div class="footer-section">
            <h4>Support</h4>
            <ul>
              <li><a routerLink="/contact">Contact Us</a></li>
              <li><a routerLink="/faq">FAQ</a></li>
              <li><a routerLink="/shipping">Shipping & Returns</a></li>
              <li><a routerLink="/warranty">Warranty</a></li>
            </ul>
          </div>
          
          <div class="footer-section">
            <h4>Stay Updated</h4>
            <div class="newsletter">
              <input type="email" placeholder="Your email address" class="form-input">
              <button class="btn btn-secondary">Subscribe</button>
            </div>
          </div>
        </div>
        
        <div class="footer-bottom">
          <p>&copy; 2025 WatchLuxe. All rights reserved.</p>
          <div class="footer-links">
            <a routerLink="/privacy">Privacy Policy</a>
            <a routerLink="/terms">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background-color: var(--primary-color);
      color: white;
      padding: calc(var(--spacing-unit) * 6) 0 calc(var(--spacing-unit) * 3);
    }
    
    .footer-content {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: calc(var(--spacing-unit) * 4);
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .footer h3, .footer h4 {
      color: white;
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .footer p {
      opacity: 0.8;
    }
    
    .footer ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .footer ul li {
      margin-bottom: var(--spacing-unit);
    }
    
    .footer a {
      color: rgba(255, 255, 255, 0.8);
      transition: color 0.3s ease;
    }
    
    .footer a:hover {
      color: var(--secondary-color);
    }
    
    .newsletter {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-unit);
    }
    
    .newsletter .form-input {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
    }
    
    .newsletter .form-input::placeholder {
      color: rgba(255, 255, 255, 0.5);
    }
    
    .footer-bottom {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: calc(var(--spacing-unit) * 3);
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      font-size: 0.875rem;
    }
    
    .footer-links {
      display: flex;
      gap: calc(var(--spacing-unit) * 2);
    }
    
    @media (max-width: 768px) {
      .footer-bottom {
        flex-direction: column;
        text-align: center;
      }
      
      .footer-links {
        margin-top: var(--spacing-unit);
      }
    }
  `]
})
export class FooterComponent {}