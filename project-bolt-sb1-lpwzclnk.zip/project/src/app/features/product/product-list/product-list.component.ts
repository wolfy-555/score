import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute } from '@angular/router';
import { ProductService, Product } from '../../../core/services/product.service';
import { CartService } from '../../../core/services/cart.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="product-list-container">
      <div class="container">
        <header class="page-header">
          <h1>{{ categoryTitle }}</h1>
          <p *ngIf="products.length">{{ products.length }} watches available</p>
        </header>
        
        <div class="filters">
          <div class="filter-group">
            <label>Sort By:</label>
            <select (change)="sortProducts($event)">
              <option value="name">Name (A-Z)</option>
              <option value="name-desc">Name (Z-A)</option>
              <option value="price-low">Price (Low to High)</option>
              <option value="price-high">Price (High to Low)</option>
            </select>
          </div>
        </div>
        
        <div *ngIf="loading" class="loading">
          <p>Loading products...</p>
        </div>
        
        <div *ngIf="!loading && products.length === 0" class="no-products">
          <p>No products found in this category.</p>
          <a routerLink="/products" class="btn btn-primary">View All Watches</a>
        </div>
        
        <div *ngIf="!loading && products.length > 0" class="products-grid">
          <div *ngFor="let product of products" class="product-card">
            <div class="product-image" [style.background-image]="'url(' + product.images[0] + ')'"></div>
            <div class="product-info">
              <h3>{{ product.name }}</h3>
              <span class="product-category">{{ product.category }}</span>
              <span class="product-price">${{ product.price.toFixed(2) }}</span>
              
              <div class="product-actions">
                <a [routerLink]="['/products/detail', product.id]" class="btn btn-primary">View Details</a>
                <button class="btn btn-secondary" (click)="addToCart(product)">Add to Cart</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .product-list-container {
      padding: calc(var(--spacing-unit) * 4) 0;
    }
    
    .page-header {
      margin-bottom: calc(var(--spacing-unit) * 4);
      text-align: center;
    }
    
    .filters {
      display: flex;
      justify-content: flex-end;
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .filter-group {
      display: flex;
      align-items: center;
      gap: var(--spacing-unit);
    }
    
    .filter-group select {
      padding: calc(var(--spacing-unit) * 1);
      border-radius: var(--border-radius);
      border: 1px solid #ccc;
      background-color: white;
      font-size: 0.9rem;
    }
    
    .loading, .no-products {
      text-align: center;
      padding: calc(var(--spacing-unit) * 8) 0;
    }
    
    .no-products p {
      margin-bottom: calc(var(--spacing-unit) * 3);
      color: var(--text-secondary);
    }
    
    .products-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: calc(var(--spacing-unit) * 3);
    }
    
    .product-card {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .product-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
    }
    
    .product-image {
      height: 250px;
      background-size: cover;
      background-position: center;
    }
    
    .product-info {
      padding: calc(var(--spacing-unit) * 3);
    }
    
    .product-card h3 {
      margin-bottom: var(--spacing-unit);
      font-size: 1.25rem;
    }
    
    .product-category {
      display: inline-block;
      background-color: var(--background-light);
      padding: calc(var(--spacing-unit) * 0.5) var(--spacing-unit);
      border-radius: var(--border-radius);
      font-size: 0.875rem;
      color: var(--text-secondary);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .product-price {
      display: block;
      font-weight: 600;
      font-size: 1.25rem;
      color: var(--primary-color);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .product-actions {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-unit);
    }
    
    @media (max-width: 576px) {
      .filters {
        justify-content: center;
      }
    }
  `]
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  loading = true;
  category: string | null = null;
  categoryTitle = 'All Watches';
  
  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private route: ActivatedRoute
  ) {}
  
  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.category = params.get('category');
      this.loadProducts();
      
      if (this.category) {
        this.categoryTitle = `${this.category.charAt(0) + this.category.slice(1).toLowerCase()} Watches`;
      } else {
        this.categoryTitle = 'All Watches';
      }
    });
  }
  
  loadProducts(): void {
    this.loading = true;
    
    if (this.category) {
      this.productService.getProductsByCategory(this.category).subscribe(products => {
        this.products = products;
        this.loading = false;
      });
    } else {
      this.productService.getAllProducts().subscribe(products => {
        this.products = products;
        this.loading = false;
      });
    }
  }
  
  sortProducts(event: Event): void {
    const sortBy = (event.target as HTMLSelectElement).value;
    
    switch (sortBy) {
      case 'name':
        this.products.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-desc':
        this.products.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case 'price-low':
        this.products.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        this.products.sort((a, b) => b.price - a.price);
        break;
    }
  }
  
  addToCart(product: Product): void {
    this.cartService.addToCart(product, 1);
    alert(`${product.name} added to cart!`);
  }
}