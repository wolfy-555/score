import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductService, Product } from '../../core/services/product.service';

interface HeroSection {
  title: string;
  subtitle: string;
  imageUrl: string;
  ctaText: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="home-container">
      <!-- Hero Section -->
      <section class="hero" [style.background-image]="'url(' + currentHero.imageUrl + ')'">
        <div class="container">
          <div class="hero-content">
            <h1>{{ currentHero.title }}</h1>
            <p>{{ currentHero.subtitle }}</p>
            <a routerLink="/products" class="btn btn-primary">{{ currentHero.ctaText }}</a>
          </div>
        </div>
      </section>
      
      <!-- Categories Section -->
      <section class="categories">
        <div class="container">
          <h2 class="section-title">Explore Our Collections</h2>
          
          <div class="categories-grid">
            <a routerLink="/products/ANALOGUE" class="category-card">
              <div class="category-image" style="background-image: url('https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg')"></div>
              <h3>Analogue</h3>
              <p>Timeless classics for every occasion</p>
            </a>
            
            <a routerLink="/products/DIGITAL" class="category-card">
              <div class="category-image" style="background-image: url('https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg')"></div>
              <h3>Digital</h3>
              <p>Smart features for the modern lifestyle</p>
            </a>
            
            <a routerLink="/products/LUXURY" class="category-card">
              <div class="category-image" style="background-image: url('https://images.pexels.com/photos/9979922/pexels-photo-9979922.jpeg')"></div>
              <h3>Luxury</h3>
              <p>Premium craftsmanship and exquisite materials</p>
            </a>
          </div>
        </div>
      </section>
      
      <!-- Featured Products -->
      <section class="featured-products">
        <div class="container">
          <h2 class="section-title">Featured Timepieces</h2>
          
          <div class="products-grid">
            <div *ngFor="let product of featuredProducts" class="product-card">
              <div class="product-image" [style.background-image]="'url(' + product.images[0] + ')'"></div>
              <div class="product-info">
                <h3>{{ product.name }}</h3>
                <span class="product-category">{{ product.category }}</span>
                <span class="product-price">${{ product.price.toFixed(2) }}</span>
                <a [routerLink]="['/products', product.id]" class="btn btn-primary">View Details</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <!-- Newsletter Section -->
      <section class="newsletter">
        <div class="container">
          <div class="newsletter-content">
            <h2>Stay Updated</h2>
            <p>Subscribe to our newsletter for exclusive offers and updates on new arrivals.</p>
            
            <div class="newsletter-form">
              <input type="email" placeholder="Your email address" class="form-input">
              <button class="btn btn-secondary">Subscribe</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .hero {
      height: 80vh;
      background-size: cover;
      background-position: center;
      color: white;
      position: relative;
      display: flex;
      align-items: center;
    }
    
    .hero::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(to right, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 100%);
    }
    
    .hero-content {
      position: relative;
      z-index: 1;
      max-width: 600px;
    }
    
    .hero h1 {
      font-size: 3.5rem;
      margin-bottom: calc(var(--spacing-unit) * 2);
      color: white;
    }
    
    .hero p {
      font-size: 1.25rem;
      margin-bottom: calc(var(--spacing-unit) * 4);
      opacity: 0.9;
    }
    
    .section-title {
      text-align: center;
      margin-bottom: calc(var(--spacing-unit) * 6);
      position: relative;
    }
    
    .section-title::after {
      content: '';
      position: absolute;
      bottom: -15px;
      left: 50%;
      transform: translateX(-50%);
      width: 60px;
      height: 3px;
      background-color: var(--secondary-color);
    }
    
    .categories {
      padding: calc(var(--spacing-unit) * 8) 0;
    }
    
    .categories-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: calc(var(--spacing-unit) * 4);
    }
    
    .category-card {
      display: block;
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      color: var(--text-primary);
      text-align: center;
      padding-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .category-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
      color: var(--text-primary);
    }
    
    .category-image {
      height: 250px;
      background-size: cover;
      background-position: center;
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .category-card h3 {
      margin-bottom: var(--spacing-unit);
    }
    
    .category-card p {
      color: var(--text-secondary);
      padding: 0 calc(var(--spacing-unit) * 2);
    }
    
    .featured-products {
      padding: calc(var(--spacing-unit) * 8) 0;
      background-color: var(--background-light);
    }
    
    .products-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: calc(var(--spacing-unit) * 3);
    }
    
    .product-card {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .product-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
    }
    
    .product-image {
      height: 250px;
      background-size: cover;
      background-position: center;
    }
    
    .product-info {
      padding: calc(var(--spacing-unit) * 3);
    }
    
    .product-card h3 {
      margin-bottom: var(--spacing-unit);
      font-size: 1.25rem;
    }
    
    .product-category {
      display: inline-block;
      background-color: var(--background-light);
      padding: calc(var(--spacing-unit) * 0.5) var(--spacing-unit);
      border-radius: var(--border-radius);
      font-size: 0.875rem;
      color: var(--text-secondary);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .product-price {
      display: block;
      font-weight: 600;
      font-size: 1.25rem;
      color: var(--primary-color);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .newsletter {
      padding: calc(var(--spacing-unit) * 8) 0;
      background-color: var(--primary-color);
      color: white;
    }
    
    .newsletter-content {
      text-align: center;
      max-width: 700px;
      margin: 0 auto;
    }
    
    .newsletter h2 {
      color: white;
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .newsletter p {
      margin-bottom: calc(var(--spacing-unit) * 4);
      opacity: 0.9;
    }
    
    .newsletter-form {
      display: flex;
      gap: var(--spacing-unit);
      max-width: 500px;
      margin: 0 auto;
      flex-wrap: wrap;
    }
    
    .newsletter-form .form-input {
      flex: 1;
      min-width: 250px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
    }
    
    .newsletter-form .form-input::placeholder {
      color: rgba(255, 255, 255, 0.7);
    }
    
    @media (max-width: 768px) {
      .hero h1 {
        font-size: 2.5rem;
      }
      
      .newsletter-form {
        flex-direction: column;
      }
      
      .newsletter-form .btn {
        width: 100%;
      }
    }
  `]
})
export class HomeComponent implements OnInit {
  heroes: HeroSection[] = [
    {
      title: 'Timeless Elegance',
      subtitle: 'Discover our collection of premium timepieces crafted with precision and style.',
      imageUrl: 'https://images.pexels.com/photos/9981171/pexels-photo-9981171.jpeg',
      ctaText: 'Shop Now'
    },
    {
      title: 'Modern Innovation',
      subtitle: 'Experience the perfect blend of traditional craftsmanship and cutting-edge technology.',
      imageUrl: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg',
      ctaText: 'Explore Collection'
    },
    {
      title: 'Luxury Redefined',
      subtitle: 'Elevate your style with our exclusive selection of luxury watches.',
      imageUrl: 'https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg',
      ctaText: 'View Luxury Collection'
    }
  ];
  
  currentHero: HeroSection = this.heroes[0];
  featuredProducts: Product[] = [];
  
  constructor(private productService: ProductService) {}
  
  ngOnInit(): void {
    // Fetch featured products
    this.productService.getAllProducts().subscribe(products => {
      // Get 3 random products to feature
      this.featuredProducts = this.getRandomProducts(products, 3);
    });
    
    // Set up hero rotation
    this.rotateHeroes();
  }
  
  rotateHeroes(): void {
    let currentIndex = 0;
    
    setInterval(() => {
      currentIndex = (currentIndex + 1) % this.heroes.length;
      this.currentHero = this.heroes[currentIndex];
    }, 5000);
  }
  
  getRandomProducts(products: Product[], count: number): Product[] {
    const shuffled = [...products].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }
}