import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductService } from '../../../core/services/product.service';
import { CartService } from '../../../core/services/cart.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="admin-dashboard">
      <div class="container">
        <header class="page-header">
          <h1>Admin Dashboard</h1>
          <p>Welcome to the admin panel. Manage your store here.</p>
        </header>
        
        <div class="dashboard-stats">
          <div class="stat-card">
            <h3>Total Products</h3>
            <div class="stat-value">{{ productCount }}</div>
            <a routerLink="/admin/products" class="stat-link">Manage Products</a>
          </div>
          
          <div class="stat-card">
            <h3>Low Stock Products</h3>
            <div class="stat-value">{{ lowStockCount }}</div>
            <a routerLink="/admin/products" class="stat-link">View Details</a>
          </div>
          
          <div class="stat-card">
            <h3>Orders (Demo)</h3>
            <div class="stat-value">0</div>
            <a href="#" class="stat-link">View Orders</a>
          </div>
          
          <div class="stat-card">
            <h3>Revenue (Demo)</h3>
            <div class="stat-value">$0.00</div>
            <a href="#" class="stat-link">Sales Report</a>
          </div>
        </div>
        
        <div class="dashboard-actions">
          <div class="action-card">
            <h3>Quick Actions</h3>
            <ul class="action-list">
              <li><a routerLink="/admin/products">Manage Products</a></li>
              <li><a href="#">Process Orders</a></li>
              <li><a href="#">Update Inventory</a></li>
              <li><a href="#">Manage Users</a></li>
            </ul>
          </div>
          
          <div class="action-card">
            <h3>Recent Activity</h3>
            <p class="no-activity">No recent activity to display.</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .admin-dashboard {
      padding: calc(var(--spacing-unit) * 4) 0;
    }
    
    .page-header {
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .dashboard-stats {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: calc(var(--spacing-unit) * 3);
      margin-bottom: calc(var(--spacing-unit) * 6);
    }
    
    .stat-card {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: calc(var(--spacing-unit) * 3);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
    }
    
    .stat-card h3 {
      margin-bottom: calc(var(--spacing-unit) * 2);
      font-size: 1.1rem;
      color: var(--text-secondary);
    }
    
    .stat-value {
      font-size: 2.5rem;
      font-weight: 600;
      color: var(--primary-color);
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .stat-link {
      display: block;
      font-size: 0.9rem;
      text-decoration: underline;
    }
    
    .dashboard-actions {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
      gap: calc(var(--spacing-unit) * 3);
    }
    
    .action-card {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: calc(var(--spacing-unit) * 3);
    }
    
    .action-card h3 {
      margin-bottom: calc(var(--spacing-unit) * 3);
      padding-bottom: var(--spacing-unit);
      border-bottom: 1px solid var(--background-light);
      font-size: 1.2rem;
    }
    
    .action-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .action-list li {
      margin-bottom: calc(var(--spacing-unit) * 2);
    }
    
    .action-list a {
      display: block;
      padding: calc(var(--spacing-unit) * 1.5);
      background-color: var(--background-light);
      border-radius: var(--border-radius);
      transition: background-color 0.3s ease, color 0.3s ease;
    }
    
    .action-list a:hover {
      background-color: var(--primary-color);
      color: white;
    }
    
    .no-activity {
      color: var(--text-secondary);
      font-style: italic;
      text-align: center;
      padding: calc(var(--spacing-unit) * 4) 0;
    }
    
    @media (max-width: 768px) {
      .dashboard-actions {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class DashboardComponent implements OnInit {
  productCount = 0;
  lowStockCount = 0;
  
  constructor(
    private productService: ProductService,
    private cartService: CartService
  ) {}
  
  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(products => {
      this.productCount = products.length;
      this.lowStockCount = products.filter(product => product.stock < 10).length;
    });
  }
}