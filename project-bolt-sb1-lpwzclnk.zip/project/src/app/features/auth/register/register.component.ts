import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService, UserCredentials } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  template: `
    <div class="auth-container">
      <div class="container">
        <div class="auth-form-container">
          <h1>Create Account</h1>
          <p class="auth-subtitle">Join us to explore our premium watch collection.</p>
          
          <form [formGroup]="registerForm" (ngSubmit)="onSubmit()" class="auth-form">
            <div class="form-group">
              <label for="fullName" class="form-label">Full Name</label>
              <input 
                type="text" 
                id="fullName" 
                formControlName="fullName" 
                class="form-input"
                [class.is-invalid]="fullName?.invalid && (fullName?.dirty || fullName?.touched)"
              >
              <div class="error-message" *ngIf="fullName?.invalid && (fullName?.dirty || fullName?.touched)">
                <div *ngIf="fullName?.errors?.['required']">Full name is required</div>
              </div>
            </div>
            
            <div class="form-group">
              <label for="email" class="form-label">Email</label>
              <input 
                type="email" 
                id="email" 
                formControlName="email" 
                class="form-input"
                [class.is-invalid]="email?.invalid && (email?.dirty || email?.touched)"
              >
              <div class="error-message" *ngIf="email?.invalid && (email?.dirty || email?.touched)">
                <div *ngIf="email?.errors?.['required']">Email is required</div>
                <div *ngIf="email?.errors?.['email']">Please enter a valid email address</div>
              </div>
            </div>
            
            <div class="form-group">
              <label for="password" class="form-label">Password</label>
              <input 
                type="password" 
                id="password" 
                formControlName="password" 
                class="form-input"
                [class.is-invalid]="password?.invalid && (password?.dirty || password?.touched)"
              >
              <div class="error-message" *ngIf="password?.invalid && (password?.dirty || password?.touched)">
                <div *ngIf="password?.errors?.['required']">Password is required</div>
                <div *ngIf="password?.errors?.['minlength']">Password must be at least 6 characters</div>
              </div>
            </div>
            
            <div class="form-group">
              <label for="confirmPassword" class="form-label">Confirm Password</label>
              <input 
                type="password" 
                id="confirmPassword" 
                formControlName="confirmPassword" 
                class="form-input"
                [class.is-invalid]="(confirmPassword?.invalid || registerForm.errors?.['passwordMismatch']) && 
                  (confirmPassword?.dirty || confirmPassword?.touched)"
              >
              <div class="error-message" *ngIf="(confirmPassword?.invalid || registerForm.errors?.['passwordMismatch']) && 
                (confirmPassword?.dirty || confirmPassword?.touched)">
                <div *ngIf="confirmPassword?.errors?.['required']">Confirm password is required</div>
                <div *ngIf="registerForm.errors?.['passwordMismatch']">Passwords do not match</div>
              </div>
            </div>
            
            <div class="form-group checkbox-group">
              <input type="checkbox" id="terms" formControlName="terms">
              <label for="terms">I agree to the Terms of Service and Privacy Policy</label>
              <div class="error-message" *ngIf="terms?.invalid && (terms?.dirty || terms?.touched)">
                <div *ngIf="terms?.errors?.['required']">You must agree to the terms to continue</div>
              </div>
            </div>
            
            <div *ngIf="errorMessage" class="auth-error">
              {{ errorMessage }}
            </div>
            
            <button type="submit" class="btn btn-primary" [disabled]="registerForm.invalid || isSubmitting">
              {{ isSubmitting ? 'Creating Account...' : 'Create Account' }}
            </button>
          </form>
          
          <div class="auth-footer">
            <p>Already have an account? <a routerLink="/auth/login">Login</a></p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      padding: calc(var(--spacing-unit) * 6) 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 70vh;
    }
    
    .auth-form-container {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      padding: calc(var(--spacing-unit) * 4);
      max-width: 500px;
      margin: 0 auto;
    }
    
    .auth-form-container h1 {
      text-align: center;
      margin-bottom: calc(var(--spacing-unit) * 1);
    }
    
    .auth-subtitle {
      text-align: center;
      color: var(--text-secondary);
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .auth-form {
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .checkbox-group {
      display: flex;
      align-items: flex-start;
      gap: var(--spacing-unit);
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .checkbox-group input {
      margin-top: 5px;
    }
    
    .auth-error {
      background-color: rgba(231, 76, 60, 0.1);
      color: var(--error-color);
      padding: var(--spacing-unit);
      border-radius: var(--border-radius);
      margin-bottom: calc(var(--spacing-unit) * 2);
      text-align: center;
    }
    
    .is-invalid {
      border-color: var(--error-color) !important;
    }
    
    .error-message {
      color: var(--error-color);
      font-size: 0.875rem;
      margin-top: calc(var(--spacing-unit) * 0.5);
    }
    
    .auth-form .btn {
      width: 100%;
    }
    
    .auth-footer {
      text-align: center;
      margin-top: calc(var(--spacing-unit) * 2);
      color: var(--text-secondary);
    }
    
    .auth-footer a {
      color: var(--accent-color);
      font-weight: 500;
    }
  `]
})
export class RegisterComponent {
  registerForm: FormGroup;
  isSubmitting = false;
  errorMessage = '';
  
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      terms: [false, Validators.requiredTrue]
    }, {
      validators: this.passwordMatchValidator
    });
  }
  
  get fullName() { return this.registerForm.get('fullName'); }
  get email() { return this.registerForm.get('email'); }
  get password() { return this.registerForm.get('password'); }
  get confirmPassword() { return this.registerForm.get('confirmPassword'); }
  get terms() { return this.registerForm.get('terms'); }
  
  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    
    return password === confirmPassword ? null : { passwordMismatch: true };
  }
  
  onSubmit() {
    if (this.registerForm.invalid) {
      return;
    }
    
    this.isSubmitting = true;
    this.errorMessage = '';
    
    const userData: UserCredentials = {
      fullName: this.registerForm.value.fullName,
      email: this.registerForm.value.email,
      password: this.registerForm.value.password
    };
    
    setTimeout(() => {
      try {
        const success = this.authService.register(userData);
        
        this.isSubmitting = false;
        
        if (success) {
          this.router.navigate(['/']);
        }
      } catch (error) {
        this.isSubmitting = false;
        this.errorMessage = 'Registration failed. Please try again.';
      }
    }, 1000); // Simulating API call
  }
}