import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductService, Product } from '../../../core/services/product.service';

interface ProductManagement extends Product {
  createdAt: Date;
  lastModified: Date;
  status: 'ACTIVE' | 'INACTIVE';
}

@Component({
  selector: 'app-product-management',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="product-management">
      <div class="container">
        <header class="page-header">
          <h1>Product Management</h1>
          <p>Manage your product inventory here.</p>
        </header>
        
        <div class="management-actions">
          <button class="btn btn-primary">Add New Product</button>
          
          <div class="filters">
            <div class="filter-group">
              <label>Filter:</label>
              <select>
                <option value="all">All Products</option>
                <option value="active">Active Products</option>
                <option value="inactive">Inactive Products</option>
                <option value="low-stock">Low Stock</option>
              </select>
            </div>
            
            <div class="search-box">
              <input type="text" placeholder="Search products...">
              <button>Search</button>
            </div>
          </div>
        </div>
        
        <div class="products-table">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let product of products">
                <td>{{ product.id }}</td>
                <td>
                  <div class="product-image">
                    <img [src]="product.images[0]" [alt]="product.name">
                  </div>
                </td>
                <td>{{ product.name }}</td>
                <td>{{ product.category }}</td>
                <td>${{ product.price.toFixed(2) }}</td>
                <td>
                  <span [class.low-stock]="product.stock < 10">
                    {{ product.stock }}
                  </span>
                </td>
                <td>
                  <span class="status-badge" [class.active]="product.status === 'ACTIVE'" [class.inactive]="product.status === 'INACTIVE'">
                    {{ product.status }}
                  </span>
                </td>
                <td>
                  <div class="action-buttons">
                    <button class="btn-icon edit">Edit</button>
                    <button class="btn-icon delete">Delete</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .product-management {
      padding: calc(var(--spacing-unit) * 4) 0;
    }
    
    .page-header {
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .management-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: calc(var(--spacing-unit) * 4);
      flex-wrap: wrap;
      gap: calc(var(--spacing-unit) * 2);
    }
    
    .filters {
      display: flex;
      gap: calc(var(--spacing-unit) * 2);
      flex-wrap: wrap;
    }
    
    .filter-group {
      display: flex;
      align-items: center;
      gap: var(--spacing-unit);
    }
    
    .filter-group select {
      padding: calc(var(--spacing-unit) * 1);
      border-radius: var(--border-radius);
      border: 1px solid #ccc;
      background-color: white;
    }
    
    .search-box {
      display: flex;
    }
    
    .search-box input {
      padding: calc(var(--spacing-unit) * 1);
      border: 1px solid #ccc;
      border-radius: var(--border-radius) 0 0 var(--border-radius);
      width: 200px;
    }
    
    .search-box button {
      padding: calc(var(--spacing-unit) * 1);
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 0 var(--border-radius) var(--border-radius) 0;
      cursor: pointer;
    }
    
    .products-table {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      overflow-x: auto;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
    }
    
    th, td {
      padding: calc(var(--spacing-unit) * 2);
      text-align: left;
      border-bottom: 1px solid var(--background-light);
    }
    
    th {
      background-color: var(--background-light);
      font-weight: 600;
    }
    
    tr:last-child td {
      border-bottom: none;
    }
    
    .product-image {
      width: 50px;
      height: 50px;
      border-radius: var(--border-radius);
      overflow: hidden;
    }
    
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .low-stock {
      color: var(--error-color);
      font-weight: 500;
    }
    
    .status-badge {
      display: inline-block;
      padding: calc(var(--spacing-unit) * 0.5) var(--spacing-unit);
      border-radius: var(--border-radius);
      font-size: 0.75rem;
      font-weight: 500;
    }
    
    .status-badge.active {
      background-color: rgba(46, 204, 113, 0.2);
      color: var(--success-color);
    }
    
    .status-badge.inactive {
      background-color: rgba(231, 76, 60, 0.2);
      color: var(--error-color);
    }
    
    .action-buttons {
      display: flex;
      gap: var(--spacing-unit);
    }
    
    .btn-icon {
      padding: calc(var(--spacing-unit) * 0.75) var(--spacing-unit);
      border-radius: var(--border-radius);
      border: none;
      font-size: 0.875rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    
    .btn-icon.edit {
      background-color: rgba(52, 152, 219, 0.2);
      color: var(--accent-color);
    }
    
    .btn-icon.edit:hover {
      background-color: rgba(52, 152, 219, 0.3);
    }
    
    .btn-icon.delete {
      background-color: rgba(231, 76, 60, 0.2);
      color: var(--error-color);
    }
    
    .btn-icon.delete:hover {
      background-color: rgba(231, 76, 60, 0.3);
    }
    
    @media (max-width: 992px) {
      .management-actions {
        flex-direction: column;
        align-items: flex-start;
      }
      
      .filters {
        width: 100%;
      }
    }
  `]
})
export class ProductManagementComponent implements OnInit {
  products: ProductManagement[] = [];
  
  constructor(private productService: ProductService) {}
  
  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(products => {
      // Convert products to ProductManagement
      this.products = products.map(product => ({
        ...product,
        createdAt: new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000),
        lastModified: new Date(Date.now() - Math.floor(Math.random() * 7) * 24 * 60 * 60 * 1000),
        status: Math.random() > 0.2 ? 'ACTIVE' : 'INACTIVE'
      }));
    });
  }
}