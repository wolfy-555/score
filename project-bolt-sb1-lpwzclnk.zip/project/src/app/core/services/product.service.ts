import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';

export interface Product {
  id: string;
  name: string;
  category: 'ANALOGUE' | 'DIGITAL' | 'LUXURY';
  price: number;
  description: string;
  specifications: Record<string, string>;
  images: string[];
  stock: number;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products: Product[] = [
    {
      id: '1',
      name: 'Classic Chronograph',
      category: 'ANALOGUE',
      price: 299.99,
      description: 'A timeless analogue chronograph watch with premium leather strap and stainless steel case.',
      specifications: {
        'Case Material': 'Stainless Steel',
        'Strap': 'Genuine Leather',
        'Movement': 'Quartz',
        'Water Resistance': '50m',
        'Case Diameter': '42mm'
      },
      images: [
        'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg',
        'https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg'
      ],
      stock: 15
    },
    {
      id: '2',
      name: 'Smart Digital Pro',
      category: 'DIGITAL',
      price: 199.99,
      description: 'Advanced digital watch with smart features, fitness tracking, and long battery life.',
      specifications: {
        'Display': 'OLED',
        'Battery Life': 'Up to 7 days',
        'Water Resistance': '30m',
        'Connectivity': 'Bluetooth 5.0',
        'Sensors': 'Heart Rate, Accelerometer'
      },
      images: [
        'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
        'https://images.pexels.com/photos/280250/pexels-photo-280250.jpeg'
      ],
      stock: 22
    },
    {
      id: '3',
      name: 'Swiss Elite Automatic',
      category: 'LUXURY',
      price: 2499.99,
      description: 'Premium Swiss-made automatic watch with sapphire crystal and exhibition caseback.',
      specifications: {
        'Case Material': '18K Gold Plated Stainless Steel',
        'Strap': 'Alligator Leather',
        'Movement': 'Swiss Automatic',
        'Water Resistance': '100m',
        'Crystal': 'Sapphire with Anti-Reflective Coating'
      },
      images: [
        'https://images.pexels.com/photos/9979922/pexels-photo-9979922.jpeg',
        'https://images.pexels.com/photos/1697214/pexels-photo-1697214.jpeg'
      ],
      stock: 5
    },
    {
      id: '4',
      name: 'Urban Minimalist',
      category: 'ANALOGUE',
      price: 159.99,
      description: 'Clean, minimalist design with a slim profile and mesh band for everyday elegance.',
      specifications: {
        'Case Material': 'Brushed Steel',
        'Strap': 'Stainless Steel Mesh',
        'Movement': 'Japanese Quartz',
        'Water Resistance': '30m',
        'Case Diameter': '38mm'
      },
      images: [
        'https://images.pexels.com/photos/2783873/pexels-photo-2783873.jpeg',
        'https://images.pexels.com/photos/236915/pexels-photo-236915.jpeg'
      ],
      stock: 18
    },
    {
      id: '5',
      name: 'Sports Multi-Function',
      category: 'DIGITAL',
      price: 249.99,
      description: 'Rugged sports watch with multiple functions like altimeter, barometer, and compass.',
      specifications: {
        'Case Material': 'Reinforced Composite',
        'Strap': 'Silicone Rubber',
        'Battery Life': 'Up to 14 days',
        'Water Resistance': '100m',
        'Special Features': 'GPS, Altimeter, Barometer'
      },
      images: [
        'https://images.pexels.com/photos/325153/pexels-photo-325153.jpeg',
        'https://images.pexels.com/photos/2494608/pexels-photo-2494608.jpeg'
      ],
      stock: 10
    },
    {
      id: '6',
      name: 'Diamond Encrusted Gold',
      category: 'LUXURY',
      price: 5999.99,
      description: 'Opulent gold watch with genuine diamond hour markers and mother of pearl dial.',
      specifications: {
        'Case Material': 'Solid 18K Gold',
        'Strap': 'Gold Bracelet',
        'Movement': 'Swiss Automatic',
        'Dial': 'Mother of Pearl',
        'Gemstones': 'Genuine Diamonds'
      },
      images: [
        'https://images.pexels.com/photos/47856/rolex-wrist-watch-clock-time-47856.jpeg',
        'https://images.pexels.com/photos/9978986/pexels-photo-9978986.jpeg'
      ],
      stock: 3
    }
  ];
  
  constructor() {}
  
  getAllProducts(): Observable<Product[]> {
    // Simulate API delay
    return of(this.products).pipe(delay(500));
  }
  
  getProductById(id: string): Observable<Product | undefined> {
    return this.getAllProducts().pipe(
      map(products => products.find(product => product.id === id))
    );
  }
  
  getProductsByCategory(category: string): Observable<Product[]> {
    return this.getAllProducts().pipe(
      map(products => products.filter(product => 
        product.category === category
      ))
    );
  }
}