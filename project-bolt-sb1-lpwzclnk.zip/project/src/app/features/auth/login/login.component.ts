import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  template: `
    <div class="auth-container">
      <div class="container">
        <div class="auth-form-container">
          <h1>Login</h1>
          <p class="auth-subtitle">Welcome back! Please enter your credentials to access your account.</p>
          
          <form [formGroup]="loginForm" (ngSubmit)="onSubmit()" class="auth-form">
            <div class="form-group">
              <label for="email" class="form-label">Email</label>
              <input 
                type="email" 
                id="email" 
                formControlName="email" 
                class="form-input"
                [class.is-invalid]="email?.invalid && (email?.dirty || email?.touched)"
              >
              <div class="error-message" *ngIf="email?.invalid && (email?.dirty || email?.touched)">
                <div *ngIf="email?.errors?.['required']">Email is required</div>
                <div *ngIf="email?.errors?.['email']">Please enter a valid email address</div>
              </div>
            </div>
            
            <div class="form-group">
              <label for="password" class="form-label">Password</label>
              <input 
                type="password" 
                id="password" 
                formControlName="password" 
                class="form-input"
                [class.is-invalid]="password?.invalid && (password?.dirty || password?.touched)"
              >
              <div class="error-message" *ngIf="password?.invalid && (password?.dirty || password?.touched)">
                <div *ngIf="password?.errors?.['required']">Password is required</div>
                <div *ngIf="password?.errors?.['minlength']">Password must be at least 6 characters</div>
              </div>
            </div>
            
            <div class="form-footer">
              <div class="remember-me">
                <input type="checkbox" id="remember">
                <label for="remember">Remember me</label>
              </div>
              
              <a href="#" class="forgot-password">Forgot password?</a>
            </div>
            
            <div *ngIf="errorMessage" class="auth-error">
              {{ errorMessage }}
            </div>
            
            <button type="submit" class="btn btn-primary" [disabled]="loginForm.invalid || isSubmitting">
              {{ isSubmitting ? 'Logging in...' : 'Login' }}
            </button>
          </form>
          
          <div class="auth-footer">
            <p>Don't have an account? <a routerLink="/auth/register">Register</a></p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      padding: calc(var(--spacing-unit) * 6) 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 70vh;
    }
    
    .auth-form-container {
      background-color: var(--background-white);
      border-radius: var(--border-radius);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      padding: calc(var(--spacing-unit) * 4);
      max-width: 500px;
      margin: 0 auto;
    }
    
    .auth-form-container h1 {
      text-align: center;
      margin-bottom: calc(var(--spacing-unit) * 1);
    }
    
    .auth-subtitle {
      text-align: center;
      color: var(--text-secondary);
      margin-bottom: calc(var(--spacing-unit) * 4);
    }
    
    .auth-form {
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .form-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: calc(var(--spacing-unit) * 3);
    }
    
    .remember-me {
      display: flex;
      align-items: center;
      gap: calc(var(--spacing-unit) * 0.5);
    }
    
    .forgot-password {
      color: var(--accent-color);
      font-size: 0.9rem;
    }
    
    .auth-error {
      background-color: rgba(231, 76, 60, 0.1);
      color: var(--error-color);
      padding: var(--spacing-unit);
      border-radius: var(--border-radius);
      margin-bottom: calc(var(--spacing-unit) * 2);
      text-align: center;
    }
    
    .is-invalid {
      border-color: var(--error-color) !important;
    }
    
    .error-message {
      color: var(--error-color);
      font-size: 0.875rem;
      margin-top: calc(var(--spacing-unit) * 0.5);
    }
    
    .auth-form .btn {
      width: 100%;
    }
    
    .auth-footer {
      text-align: center;
      margin-top: calc(var(--spacing-unit) * 2);
      color: var(--text-secondary);
    }
    
    .auth-footer a {
      color: var(--accent-color);
      font-weight: 500;
    }
  `]
})
export class LoginComponent {
  loginForm: FormGroup;
  isSubmitting = false;
  errorMessage = '';
  
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  
  get email() { return this.loginForm.get('email'); }
  get password() { return this.loginForm.get('password'); }
  
  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }
    
    this.isSubmitting = true;
    this.errorMessage = '';
    
    const credentials = this.loginForm.value;
    
    setTimeout(() => {
      const success = this.authService.login(credentials);
      
      this.isSubmitting = false;
      
      if (success) {
        this.router.navigate(['/']);
      } else {
        this.errorMessage = 'Invalid email or password. Try using "admin@example.com" for demo.';
      }
    }, 1000); // Simulating API call
  }
}