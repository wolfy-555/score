import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Product } from './product.service';

export interface CartItem extends Product {
  quantity: number;
  subtotal: number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartSubject = new BehaviorSubject<CartItem[]>([]);
  public cart$ = this.cartSubject.asObservable();
  
  constructor() {
    // Check if cart is stored in localStorage
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
      this.cartSubject.next(JSON.parse(storedCart));
    }
  }
  
  getCart(): CartItem[] {
    return this.cartSubject.value;
  }
  
  addToCart(product: Product, quantity: number = 1): void {
    const currentCart = this.cartSubject.value;
    const existingItem = currentCart.find(item => item.id === product.id);
    
    let updatedCart: CartItem[];
    
    if (existingItem) {
      // If item already exists, update the quantity
      updatedCart = currentCart.map(item => 
        item.id === product.id
          ? { 
              ...item, 
              quantity: item.quantity + quantity,
              subtotal: (item.quantity + quantity) * item.price
            }
          : item
      );
    } else {
      // If item doesn't exist, add it to the cart
      const newItem: CartItem = {
        ...product,
        quantity,
        subtotal: quantity * product.price
      };
      
      updatedCart = [...currentCart, newItem];
    }
    
    // Update localStorage and the cart subject
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    this.cartSubject.next(updatedCart);
  }
  
  updateQuantity(productId: string, quantity: number): void {
    if (quantity <= 0) {
      this.removeFromCart(productId);
      return;
    }
    
    const currentCart = this.cartSubject.value;
    const updatedCart = currentCart.map(item => 
      item.id === productId
        ? { 
            ...item, 
            quantity: quantity,
            subtotal: quantity * item.price
          }
        : item
    );
    
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    this.cartSubject.next(updatedCart);
  }
  
  removeFromCart(productId: string): void {
    const currentCart = this.cartSubject.value;
    const updatedCart = currentCart.filter(item => item.id !== productId);
    
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    this.cartSubject.next(updatedCart);
  }
  
  clearCart(): void {
    localStorage.removeItem('cart');
    this.cartSubject.next([]);
  }
  
  getCartTotal(): number {
    return this.cartSubject.value.reduce((total, item) => total + item.subtotal, 0);
  }
  
  getCartItemCount(): number {
    return this.cartSubject.value.reduce((count, item) => count + item.quantity, 0);
  }
}